var config = require('config');
var dbbase=require('../../models/db/'+config.get('db.server')+'/functions').poolDatabase;

exports.query    = {
    selectDb       : function(tbl,cnd,cb){dbbase.selectDb(tbl,cnd,function(row){return cb(row);});},
    updateDb       : function(tbl,data,cnd,cb){dbbase.updateDb(tbl,data,cnd,function(row){return cb(row);});},
    insertDb       : function(tbl,data,cb){dbbase.insertDb(tbl,data,function(row){return cb(row);});},
    selectCustomDb       : function(sql,cb){dbbase.selectCustomDb(sql,function(row){return cb(row);});},
    updateDbCustom       : function(tbl,data,cnd,cb){dbbase.updateDbCustom(tbl,data,cnd,function(row){return cb(row);});},
    deleteDb       : function(tbl,data,cb){dbbase.deleteDb(tbl,data,function(row){return cb(row);});},
    openingBalanceFatch       : function(data,cb){dbbase.openingBalanceFatch(data,function(row){return cb(row);});},
    getSalesItem       : function(data,cb){dbbase.getSalesItem(data,function(row){return cb(row);});},
    getPurchaseItem       : function(data,cb){dbbase.getPurchaseItem(data,function(row){return cb(row);});},
    getPurchaseVen       : function(data,cb){dbbase.getPurchaseVen(data,function(row){return cb(row);});},
    getSalesVen       : function(data,cb){dbbase.getSalesVen(data,function(row){return cb(row);});},
    getReceiveCus       : function(data,cb){dbbase.getReceiveCus(data,function(row){return cb(row);});},
    getReceiveDeCus       : function(data,cb){dbbase.getReceiveDeCus(data,function(row){return cb(row);});},
    getPayDeCus       : function(data,cb){dbbase.getPayDeCus(data,function(row){return cb(row);});},
    getPayCus       : function(data,cb){dbbase.getPayCus(data,function(row){return cb(row);});},
    getTransferAcc       : function(data,cb){dbbase.getTransferAcc(data,function(row){return cb(row);});},
    getCrnoteCust       : function(data,cb){dbbase.getCrnoteCust(data,function(row){return cb(row);});},
    getDenoteCust       : function(data,cb){dbbase.getDenoteCust(data,function(row){return cb(row);});},
    reportSalesOut       : function(data,cb){dbbase.reportSalesOut(data,function(row){return cb(row);});},
    reportPurchaseOut       : function(data,cb){dbbase.reportPurchaseOut(data,function(row){return cb(row);});},
    reportSalesInv       : function(data,cb){dbbase.reportSalesInv(data,function(row){return cb(row);});},
    reportPurchaseInv       : function(data,cb){dbbase.reportPurchaseInv(data,function(row){return cb(row);});},
    reportSalesOutDet       : function(data,cb){dbbase.reportSalesOutDet(data,function(row){return cb(row);});},
    reportPurchaseOutDet       : function(data,cb){dbbase.reportPurchaseOutDet(data,function(row){return cb(row);});},
    reportSalesOutAgeAna       : function(data,cb){dbbase.reportSalesOutAgeAna(data,function(row){return cb(row);});},
    reportPurchaseOutAgeAna       : function(data,cb){dbbase.reportPurchaseOutAgeAna(data,function(row){return cb(row);});},
    reportSalesReg       : function(data,cb){dbbase.reportSalesReg(data,function(row){return cb(row);});},
    reportPurchaseReg       : function(data,cb){dbbase.reportPurchaseReg(data,function(row){return cb(row);});},
    reportSalesRegDet       : function(data,cb){dbbase.reportSalesRegDet(data,function(row){return cb(row);});},
    reportPurchaseRegDet       : function(data,cb){dbbase.reportPurchaseRegDet(data,function(row){return cb(row);});},
    companySetup       : function(data){dbbase.companySetup(data);},
    
};

