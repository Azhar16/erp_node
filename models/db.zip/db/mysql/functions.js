var mysql = require('mysql'),
        jsonfile = require('jsonfile'),
        config = require('config');

var dp = exports.poolDatabase = {
    pconnection: '',
    connectDB: function () {
        var mysqlPool = mysql.createPool({
            host: config.get('db.mysql.host'),
            user: config.get('db.mysql.user'),
            password: config.get('db.mysql.pass'),
            connectionLimit: 500,
            acquireTimeout: 500000,
            database: config.get('db.mysql.dbname')
        });
        var _this = this;
        mysqlPool.getConnection(function (err, connection) {
            if (err)
                throw err;
            _this.pconnection = connection;
        });
    },
    updateDb: function (tableName, data, cond, cb) {
        console.log('UPDATE ' + tableName + ' SET ? WHERE id=' + cond, data);
        this.pconnection.query('UPDATE ' + tableName + ' SET ? WHERE id=' + cond, data, function (err, res) {
            if (err)
                throw err;
            return cb(res);
        });
    },
    updateDbCustom: function (tableName, data, cond, cb) {
        console.log('UPDATE ' + tableName + ' SET ? WHERE ' + cond, data);
        this.pconnection.query('UPDATE ' + tableName + ' SET ? WHERE ' + cond, data, function (err, res) {
            if (err)
                throw err;
            return cb(res);
        });
    },
    deleteDb: function (tableName, data, cb) {
        this.pconnection.query('DELETE FROM ' + tableName + ' WHERE ' + data, function (err, res) {
            if (err)
                throw err;
            return cb(res);
        });
    },
    insertDb: function (tableName, data, cb) {
        console.log('INSERT INTO ' + tableName + ' SET ?', data);
        this.pconnection.query('INSERT INTO ' + tableName + ' SET ?', data, function (err, res) {
            if (err)
                throw err;
            return cb(res.insertId);
        });

    },
    selectDb: function (tableName, data, cb) {
        this.pconnection.query("SELECT * FROM " + tableName + " WHERE " + data, function (err, rows) {
            if (err)
                throw err;
            return cb(rows);
        });
    },
    selectCustomDb: function (query, cb) {
        this.pconnection.query(query, function (err, rows) {
            if (err)
                throw err;
            return cb(rows);
        });
    },
    companySetup: function (data) {
        var _this = this;
        var d = new Date();
        jsonfile.readFile('config/default_account.json', function (err, acc) {
            for (var k in acc) {
                var flag = (k == 'CASH') ? 'bank' : 'other';
                _this.insertDb('account', {company: data.cid, type: acc[k].type, flag: flag, tag: 'default', code: k, name: acc[k].name}, function (aid) {
                    _this.insertDb('opening_balance', {account: aid, account_from: 'account', year: d.getFullYear()}, function (oid) {});
                });
            }
        });
        _this.insertDb('settings', {company: data.cid}, function (oid) {});
    },
    openingBalanceFatch: function (data, cb) {
        var sql = "SELECT a.name,b.id,b.account,b.debit,b.credit FROM `account` a INNER JOIN opening_balance b ON a.id=b.account WHERE a.company=" + data.company + " AND b.account_from='" + data.type + "'";
        this.selectCustomDb(sql, function (row) {
            return cb(row);
        });
    },
    getSalesItem: function (data, cb) {
        var sql = "SELECT s.item,s.rate,i.name,i.unit,i.unit_two,i.unit_three,s.unit sunit,i.tax_slabe FROM `sales_item` s INNER JOIN item i ON i.id=s.item WHERE s.sales=" + data.sid;
        this.selectCustomDb(sql, function (row) {
            return cb(row);
        });
    },
    getPurchaseItem: function (data, cb) {
        var sql = "SELECT s.item,s.rate,i.name,i.unit,i.unit_two,i.unit_three,s.unit sunit,i.tax_slabe FROM `purchase_item` s INNER JOIN item i ON i.id=s.item WHERE s.purchase=" + data.sid;
        this.selectCustomDb(sql, function (row) {
            return cb(row);
        });
    },
    getCrnoteCust: function (data, cb) {
        var cnd = "";
        if (typeof data.company != 'undefined') {
            cnd += " AND p.company=" + data.company;
        }
        var sql = "SELECT p.id,DATE_FORMAT(p.date,'%d, %b %Y') date,p.cr_note_no,p.total_amount,p.due_amount,p.payment_status,c.name,c.company_name FROM `cr_note` p INNER JOIN customer c ON c.id=p.customer WHERE 1 " + cnd;
        this.selectCustomDb(sql, function (row) {
            return cb(row);
        });
    },
    getDenoteCust: function (data, cb) {
        var cnd = "";
        if (typeof data.company != 'undefined') {
            cnd += " AND p.company=" + data.company;
        }
        var sql = "SELECT p.id,DATE_FORMAT(p.date,'%d, %b %Y') date,p.de_note_no,p.total_amount,p.due_amount,p.payment_status,c.name,c.company_name FROM `de_note` p INNER JOIN customer c ON c.id=p.vendor WHERE 1 " + cnd;
        this.selectCustomDb(sql, function (row) {
            return cb(row);
        });
    },
    getPurchaseVen: function (data, cb) {
        var cnd = "";
        if (typeof data.company != 'undefined') {
            cnd += " AND p.company=" + data.company;
        }
        if (typeof data.status != 'undefined') {
            cnd += " AND p.status='" + data.status + "' ";
        }
        var sql = "SELECT p.id,DATE_FORMAT(p.bill_date,'%d, %b %Y') bill_date,DATE_FORMAT(DATE_ADD(p.bill_date, INTERVAL p.payment_due_date DAY),'%d, %b %Y') payment_due_date,p.bill_no,p.total_amount,p.due_amount,p.payment_status,c.name,c.company_name FROM `purchase` p INNER JOIN customer c ON c.id=p.customer WHERE 1 " + cnd;
        this.selectCustomDb(sql, function (row) {
            return cb(row);
        });
    },
    getSalesVen: function (data, cb) {
        var cnd = "";
        if (typeof data.company != 'undefined') {
            cnd += " AND s.company=" + data.company;
        }
        if (typeof data.status != 'undefined') {
            cnd += " AND s.status='" + data.status + "' ";
        }
        var sql = "SELECT s.id,DATE_FORMAT(s.bill_date,'%d, %b %Y') bill_date,DATE_FORMAT(DATE_ADD(s.bill_date, INTERVAL s.payment_date DAY),'%d, %b %Y') payment_date,s.invoice_no,s.total_amount,s.due_amount,s.payment_status,c.name,c.company_name FROM `sales` s INNER JOIN customer c ON c.id=s.customer WHERE 1 " + cnd;
        this.selectCustomDb(sql, function (row) {
            return cb(row);
        });
    },
    getReceiveCus: function (data, cb) {
        var cnd = "";
        if (typeof data.company != 'undefined') {
            cnd += " AND j.company=" + data.company;
        }
        var sql = "SELECT j.id,DATE_FORMAT(j.date,'%d, %b %Y') date,j.amount,c.name,c.company_name,a.name aname FROM `receive` j INNER JOIN customer c ON c.id=j.customer INNER JOIN account a ON a.id=j.account WHERE 1 " + cnd;
        this.selectCustomDb(sql, function (row) {
            return cb(row);
        });
    },
    getReceiveDeCus: function (data, cb) {
        var cnd = "";
        if (typeof data.company != 'undefined') {
            cnd += " AND j.company=" + data.company;
        }
        var sql = "SELECT * FROM ( (SELECT j.id,DATE_FORMAT(j.date,'%d, %b %Y') date,j.amount,c.name,c.company_name,a.name aname FROM `receive_de_note` j INNER JOIN customer c ON c.id=j.customer INNER JOIN account a ON a.id=j.account WHERE j.tag='receive' " + cnd+") ";
        sql += "UNION (SELECT j.id,DATE_FORMAT(j.date,'%d, %b %Y') date,j.amount,c.name,c.company_name,'Adjust' aname FROM `receive_de_note` j INNER JOIN customer c ON c.id=j.customer  WHERE j.tag='adjust' " + cnd+")  ) as tbl ORDER BY id DESC";
        this.selectCustomDb(sql, function (row) {
            return cb(row);
        });
    },
    getPayDeCus: function (data, cb) {
        var cnd = "";
        if (typeof data.company != 'undefined') {
            cnd += " AND j.company=" + data.company;
        }
        var sql = "SELECT * FROM ( (SELECT j.id,DATE_FORMAT(j.date,'%d, %b %Y') date,j.amount,c.name,c.company_name,a.name aname FROM `pay_cr_note` j INNER JOIN customer c ON c.id=j.customer INNER JOIN account a ON a.id=j.account WHERE j.tag='pay' " + cnd+") ";
        sql += "UNION (SELECT j.id,DATE_FORMAT(j.date,'%d, %b %Y') date,j.amount,c.name,c.company_name,'Adjust' aname FROM `pay_cr_note` j INNER JOIN customer c ON c.id=j.customer  WHERE j.tag='adjust' " + cnd+")  ) as tbl ORDER BY id DESC";
        this.selectCustomDb(sql, function (row) {
            return cb(row);
        });
    },
    getTransferAcc: function (data, cb) {
        var cnd = "";
        if (typeof data.company != 'undefined') {
            cnd += " AND j.company=" + data.company;
        }
        var sql = "SELECT j.id,DATE_FORMAT(j.date,'%d, %b %Y') date,j.amount,c.name fname,a.name tname,j.amount FROM `transfer` j INNER JOIN account c ON c.id=j.from_account INNER JOIN account a ON a.id=j.to_account WHERE 1 " + cnd;
        this.selectCustomDb(sql, function (row) {
            return cb(row);
        });
    },
    getPayCus: function (data, cb) {
        var cnd = "";
        if (typeof data.company != 'undefined') {
            cnd += " AND p.company=" + data.company;
        }
        var sql = "SELECT * FROM ((SELECT p.id,DATE_FORMAT(p.date,'%d, %b %Y') date,p.amount,c.name,c.company_name,a.name aname,p.transaction_type FROM `pay` p INNER JOIN customer c ON c.id=p.exp_cust_account INNER JOIN account a ON a.id=p.account WHERE transaction_type='bill' " + cnd + " ) UNION (SELECT p.id,DATE_FORMAT(p.date,'%d, %b %Y') date,p.amount,'Expences' name,'' company_name,a.name aname,p.transaction_type FROM `pay` p  INNER JOIN account a ON a.id=p.account WHERE transaction_type='expence' " + cnd + ")) as tbl ORDER BY id DESC";
        this.selectCustomDb(sql, function (row) {
            return cb(row);
        });
    },
    reportSalesOut: function (data, cb) {
        if (typeof data.fdate != 'undefined' && data.fdate != '' && typeof data.tdate != 'undefined' && data.tdate != '') {
            var sql = "SELECT c.company_name cname,sum(total_amount) tamt,sum(due_amount) damt FROM `sales` s INNER JOIN customer c on c.id=s.customer WHERE s.company='" + data.cid + "' AND s.payment_status<>'done' AND bill_date>'" + data.fdate + "' AND bill_date<'" + data.tdate + "' GROUP BY c.id";
            this.selectCustomDb(sql, function (row) {
                return cb(row);
            });
        } else {
            return cb([]);
        }
    },
    reportPurchaseOut: function (data, cb) {
        if (typeof data.fdate != 'undefined' && data.fdate != '' && typeof data.tdate != 'undefined' && data.tdate != '') {
            var sql = "SELECT c.company_name cname,sum(total_amount) tamt,sum(due_amount) damt FROM `purchase` s INNER JOIN customer c on c.id=s.customer WHERE s.company='" + data.cid + "' AND s.payment_status<>'done' AND bill_date>'" + data.fdate + "' AND bill_date<'" + data.tdate + "' GROUP BY c.id";
            this.selectCustomDb(sql, function (row) {
                return cb(row);
            });
        } else {
            return cb([]);
        }
    },
    reportSalesInv: function (data, cb) {
        if (typeof data.fdate != 'undefined' && data.fdate != '' && typeof data.tdate != 'undefined' && data.tdate != '') {
            var sql = "SELECT c.company_name cname,total_amount tamt,due_amount damt,DATE_FORMAT(s.bill_date,'%d, %b %Y') bill_date,DATE_FORMAT(DATE_ADD(s.bill_date, INTERVAL s.payment_date DAY),'%d, %b %Y') payment_date,invoice_no FROM `sales` s INNER JOIN customer c on c.id=s.customer WHERE s.company='" + data.cid + "' AND s.payment_status<>'done' AND bill_date>'" + data.fdate + "' AND bill_date<'" + data.tdate + "' ";
            this.selectCustomDb(sql, function (row) {
                return cb(row);
            });
        } else {
            return cb([]);
        }
    },
    reportPurchaseInv: function (data, cb) {
        if (typeof data.fdate != 'undefined' && data.fdate != '' && typeof data.tdate != 'undefined' && data.tdate != '') {
            var sql = "SELECT c.company_name cname,total_amount tamt,due_amount damt,DATE_FORMAT(s.bill_date,'%d, %b %Y') bill_date,DATE_FORMAT(DATE_ADD(s.bill_date, INTERVAL s.payment_due_date DAY),'%d, %b %Y') payment_date,bill_no invoice_no FROM `purchase` s INNER JOIN customer c on c.id=s.customer WHERE s.company='" + data.cid + "' AND s.payment_status<>'done' AND bill_date>'" + data.fdate + "' AND bill_date<'" + data.tdate + "' ";
            this.selectCustomDb(sql, function (row) {
                return cb(row);
            });
        } else {
            return cb([]);
        }
    },
    reportSalesOutAgeAna: function (data, cb) {
        if (typeof data.fdate != 'undefined' && data.fdate != '' && typeof data.tdate != 'undefined' && data.tdate != '') {
            var sql = "SELECT DATEDIFF(CURDATE(),bill_date) odate,c.company_name cname,total_amount tamt,due_amount damt,invoice_no FROM `sales` s INNER JOIN customer c on c.id=s.customer WHERE s.company='" + data.cid + "' AND s.payment_status<>'done' AND bill_date>'" + data.fdate + "' AND bill_date<'" + data.tdate + "' ORDER BY c.id ";
            this.selectCustomDb(sql, function (row) {
                return cb(row);
            });
        } else {
            return cb([]);
        }
    },
    reportPurchaseOutAgeAna: function (data, cb) {
        if (typeof data.fdate != 'undefined' && data.fdate != '' && typeof data.tdate != 'undefined' && data.tdate != '') {
            var sql = "SELECT DATEDIFF(CURDATE(),bill_date) odate,c.company_name cname,total_amount tamt,due_amount damt,bill_no invoice_no FROM `purchase` s INNER JOIN customer c on c.id=s.customer WHERE s.company='" + data.cid + "' AND s.payment_status<>'done' AND bill_date>'" + data.fdate + "' AND bill_date<'" + data.tdate + "' ORDER BY c.id ";
            this.selectCustomDb(sql, function (row) {
                return cb(row);
            });
        } else {
            return cb([]);
        }
    },
    reportSalesOutDet: function (data, cb) {
        if (typeof data.fdate != 'undefined' && data.fdate != '' && typeof data.tdate != 'undefined' && data.tdate != '') {
            var sql = "SELECT c.company_name cname,total_amount tamt,due_amount damt,DATE_FORMAT(s.bill_date,'%d, %b %Y') bill_date,DATE_FORMAT(DATE_ADD(s.bill_date, INTERVAL s.payment_date DAY),'%d, %b %Y') payment_date,invoice_no FROM `sales` s INNER JOIN customer c on c.id=s.customer WHERE s.company='" + data.cid + "' AND s.payment_status<>'done' AND bill_date>'" + data.fdate + "' AND bill_date<'" + data.tdate + "' ORDER BY c.id ";
            this.selectCustomDb(sql, function (row) {
                return cb(row);
            });
        } else {
            return cb([]);
        }
    },
    reportPurchaseOutDet: function (data, cb) {
        if (typeof data.fdate != 'undefined' && data.fdate != '' && typeof data.tdate != 'undefined' && data.tdate != '') {
            var sql = "SELECT c.company_name cname,total_amount tamt,due_amount damt,DATE_FORMAT(s.bill_date,'%d, %b %Y') bill_date,DATE_FORMAT(DATE_ADD(s.bill_date, INTERVAL s.payment_due_date DAY),'%d, %b %Y') payment_date,bill_no invoice_no FROM `purchase` s INNER JOIN customer c on c.id=s.customer WHERE s.company='" + data.cid + "' AND s.payment_status<>'done' AND bill_date>'" + data.fdate + "' AND bill_date<'" + data.tdate + "' ORDER BY c.id ";
            this.selectCustomDb(sql, function (row) {
                return cb(row);
            });
        } else {
            return cb([]);
        }
    },
    reportSalesReg: function (data, cb) {
        if (typeof data.fdate != 'undefined' && data.fdate != '' && typeof data.tdate != 'undefined' && data.tdate != '') {
            var sql = "SELECT c.company_name cname,sum(total_amount) tamt,sum(due_amount) damt FROM `sales` s INNER JOIN customer c on c.id=s.customer WHERE s.company='" + data.cid + "'  AND bill_date>'" + data.fdate + "' AND bill_date<'" + data.tdate + "' GROUP BY c.id";
            this.selectCustomDb(sql, function (row) {
                return cb(row);
            });
        } else {
            return cb([]);
        }
    },
    reportPurchaseReg: function (data, cb) {
        if (typeof data.fdate != 'undefined' && data.fdate != '' && typeof data.tdate != 'undefined' && data.tdate != '') {
            var sql = "SELECT c.company_name cname,sum(total_amount) tamt,sum(due_amount) damt FROM `purchase` s INNER JOIN customer c on c.id=s.customer WHERE s.company='" + data.cid + "'  AND bill_date>'" + data.fdate + "' AND bill_date<'" + data.tdate + "' GROUP BY c.id";
            this.selectCustomDb(sql, function (row) {
                return cb(row);
            });
        } else {
            return cb([]);
        }
    },
    reportSalesRegDet: function (data, cb) {
        if (typeof data.fdate != 'undefined' && data.fdate != '' && typeof data.tdate != 'undefined' && data.tdate != '') {
            var sql = "SELECT c.company_name cname,total_amount tamt,due_amount damt,DATE_FORMAT(s.bill_date,'%d, %b %Y') bill_date,DATE_FORMAT(DATE_ADD(s.bill_date, INTERVAL s.payment_date DAY),'%d, %b %Y') payment_date,invoice_no FROM `sales` s INNER JOIN customer c on c.id=s.customer WHERE s.company='" + data.cid + "'  AND bill_date>'" + data.fdate + "' AND bill_date<'" + data.tdate + "' ORDER BY c.id ";
            this.selectCustomDb(sql, function (row) {
                return cb(row);
            });
        } else {
            return cb([]);
        }
    },
    reportPurchaseRegDet: function (data, cb) {
        if (typeof data.fdate != 'undefined' && data.fdate != '' && typeof data.tdate != 'undefined' && data.tdate != '') {
            var sql = "SELECT c.company_name cname,total_amount tamt,due_amount damt,DATE_FORMAT(s.bill_date,'%d, %b %Y') bill_date,DATE_FORMAT(DATE_ADD(s.bill_date, INTERVAL s.payment_due_date DAY),'%d, %b %Y') payment_date,bill_no invoice_no FROM `purchase` s INNER JOIN customer c on c.id=s.customer WHERE s.company='" + data.cid + "'  AND bill_date>'" + data.fdate + "' AND bill_date<'" + data.tdate + "' ORDER BY c.id ";
            this.selectCustomDb(sql, function (row) {
                return cb(row);
            });
        } else {
            return cb([]);
        }
    },
};

dp.connectDB();
